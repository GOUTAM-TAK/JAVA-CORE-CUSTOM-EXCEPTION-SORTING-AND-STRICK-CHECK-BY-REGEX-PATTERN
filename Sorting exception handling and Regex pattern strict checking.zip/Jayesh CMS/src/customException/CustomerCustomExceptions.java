package customException;

public class CustomerCustomExceptions extends Exception {

	public CustomerCustomExceptions(String msg) {
		super(msg);
	}

}
